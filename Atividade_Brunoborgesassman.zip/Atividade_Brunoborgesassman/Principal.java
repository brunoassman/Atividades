// Classe Usuario
class Usuario {
    String nome;
    String cpf;

    public Usuario(String nome, String cpf) {
        this.nome = nome;
        this.cpf = cpf;
    }

    public void realizarCompra() {
        System.out.println(nome + " realizou uma compra.");
    }

    public void cancelarCompra() {
        System.out.println(nome + " cancelou a compra.");
    }

    public void visualizarVeiculos(Concessionaria concessionaria) {
        System.out.println(nome + " está visualizando os veículos.");
        concessionaria.listarVeiculos();
    }
}

class Concessionaria {
    String nome;
    String endereco;
    Veiculo[] veiculos;
    int numVeiculos;


    public Concessionaria(String nome, String endereco, int capacidade) {
        this.nome = nome;
        this.endereco = endereco;
        this.veiculos = new Veiculo[capacidade];
        this.numVeiculos = 0;
    }

    public void listarVeiculos() {
        System.out.println("Listando veículos da concessionária " + nome);
        for (int i = 0; i < numVeiculos; i++) {
            veiculos[i].exibirDetalhes();
        }
    }




    public void venderVeiculo(Veiculo veiculo) {
        System.out.println("Veículo vendido pela concessionária " + nome);
    }




    public void receberVeiculo(Veiculo veiculo) {
        if (numVeiculos < veiculos.length) {
            veiculos[numVeiculos] = veiculo;
            numVeiculos++;
        } else {
            System.out.println("Concessionária cheia, não é possível receber mais veículos.");
        }
    }
}
class Veiculo {
    String marca;
    String modelo;
    int ano;
    float preco;

    public Veiculo(String marca, String modelo, int ano, float preco) {
        this.marca = marca;
        this.modelo = modelo;
        this.ano = ano;
        this.preco = preco;
    }

    public void exibirDetalhes() {
        System.out.println("Marca: " + marca + ", Modelo: " + modelo + ", Ano: " + ano + ", Preço: " + preco);
    }

    public float calcularDesconto(float percentual) {
        return preco * (1 - percentual / 100);
    }
}


class Carro extends Veiculo {
    int quantidadePortas;

    public Carro(String marca, String modelo, int ano, float preco, int quantidadePortas) {
        super(marca, modelo, ano, preco);
        this.quantidadePortas = quantidadePortas;
    }

    public void ligarMotor() {
        System.out.println("Motor do carro " + modelo + " ligado.");
    }

    public void acelerar() {
        System.out.println("Carro " + modelo + " acelerando.");
    }

    public void frear() {
        System.out.println("Carro " + modelo + " freando.");
    }
}

class Moto extends Veiculo {
    int cilindradas;

    public Moto(String marca, String modelo, int ano, float preco, int cilindradas) {
        super(marca, modelo, ano, preco);
        this.cilindradas = cilindradas;
    }

    public void ligarMotor() {
        System.out.println("Motor da moto " + modelo + " ligado.");
    }

    public void acelerar() {
        System.out.println("Moto " + modelo + " acelerando.");
    }

    public void frear() {
        System.out.println("Moto " + modelo + " freando.");
    }
}


public class Principal {
    public static void main(String[] args) {
        Usuario usuario = new Usuario("João", "123.456.789-00");
        Concessionaria concessionaria = new Concessionaria("AutoCar", "Rua das Flores, 123", 10);

        Carro carro = new Carro("Toyota", "Corolla", 2022, 120000.0f, 4);
        Moto moto = new Moto("Honda", "CB500", 2021, 35000.0f, 500);

        concessionaria.receberVeiculo(carro);
        concessionaria.receberVeiculo(moto);

        usuario.visualizarVeiculos(concessionaria);

        carro.ligarMotor();
        carro.acelerar();
        carro.frear();

        moto.ligarMotor();
        moto.acelerar();
        moto.frear();

        usuario.realizarCompra();
        concessionaria.venderVeiculo(carro);
        usuario.cancelarCompra();
    }
}